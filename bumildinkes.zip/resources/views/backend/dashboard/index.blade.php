@extends('backend.layouts.master')

{{-- @section('title') {{ $config['page_title'] }} @endsection --}}

@section('content')
<section class="datatables">

</section>
@endsection

@section('css')

@endsection
@section('script')

<script>

    $(document).ready(function () {

   });
 </script>
@endsection
