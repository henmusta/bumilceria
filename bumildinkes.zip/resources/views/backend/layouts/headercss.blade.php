@yield('css')


<link rel="stylesheet" href="{{asset('assets/backend/dist/libs/prismjs/themes/prism-okaidia.min.css')}}">
<link rel="stylesheet" href="{{asset('assets/backend/dist/libs/datatables.net-bs5/css/dataTables.bootstrap5.min.css')}}">
<link href="{{asset('assets/backend/dist/libs/select2/dist/css/select2.min.css')}}"  rel="stylesheet" type="text/css" />
<link  id="themeColors"  rel="stylesheet" href="{{asset('assets/backend/dist/css/style.min.css')}}" />



    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet"  />

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link href="https://cdn.jsdelivr.net/npm/flatpickr@latest/dist/plugins/monthSelect/style.css" rel="stylesheet" />


