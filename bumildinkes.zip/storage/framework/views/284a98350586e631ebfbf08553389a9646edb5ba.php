        <!-- JAVASCRIPT -->
        

        


        





    


    <script src="<?php echo e(asset('assets/backend/dist/libs/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/dist/libs/simplebar/dist/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/dist/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- ---------------------------------------------- -->
    <!-- core files -->
    <!-- ---------------------------------------------- -->
    <script src="<?php echo e(asset('assets/backend/dist/js/app.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/dist/js/app.init.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/dist/js/app-style-switcher.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/dist/js/sidebarmenu.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/backend/dist/js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/dist/libs/prismjs/prism.js')); ?>"></script>

    <!-- ---------------------------------------------- -->
    <!-- current page js files -->
    <!-- ---------------------------------------------- -->
    <script src="<?php echo e(asset('assets/backend/dist/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/vendor_components/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/vendor_components/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/vendor_components/jszip/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/vendor_components/pdfmake/build/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/vendor_components/pdfmake/build/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/vendor_components/datatables.net-buttons/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/vendor_components/datatables.net-buttons/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/vendor_components/datatables.net-buttons/js/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/dist/js/datatable/datatable-advanced.init.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr@latest/dist/plugins/monthSelect/index.js"></script>


    <script src="<?php echo e(asset('assets/backend/dist/libs/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/dist/libs/select2/dist/js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/backend/dist/js/forms/select2.init.js')); ?>"></script>
<script></script>
        <?php echo $__env->yieldContent('script'); ?>
<?php /**PATH C:\xampp\htdocs\bumildinkes\resources\views/backend/layouts/footerjs.blade.php ENDPATH**/ ?>