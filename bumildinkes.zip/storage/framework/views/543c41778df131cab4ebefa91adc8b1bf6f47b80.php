<?php $__env->startSection('content'); ?>
<section class="datatables">

</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script>

    $(document).ready(function () {

   });
 </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bumildinkes\resources\views/backend/dashboard/index.blade.php ENDPATH**/ ?>